# 🔒 Security Gate: ✅ PASSED

**0 blocking issue(s)** (0 findings) · 1 advisory · scope: 1 changed file(s) (`c7199a1b14..d9265b11b5`) · 3.9s · policy `adaptive` v1

<details><summary>1 advisory finding(s) — not blocking</summary>

| Severity | Tool | Location | Rule | Why not blocking |
|---|---|---|---|---|
| MEDIUM | semgrep | `app/c/src/CWE78_OS_Command_Injection__char_console_popen_01_good.c:45` | `insecure-use-strcat-fn` | audit-grade rule (not a confirmed vulnerability) |

</details>

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 1 | 3.34 | 182 |
| gitleaks | ok | 0 | 0.49 | 60 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |
