# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (3 findings) · 6 advisory · scope: 5 changed file(s) (`..0844083122`) · 11.4s · policy `adaptive-no_differential` v1

## Blocking issues — fix before merge

### 1. [CRITICAL] SQL Injection — CWE-89 — `app/java/src/main/java/edu/demo/CWE89_SQL_Injection__getParameter_Servlet_executeQuery_01_bad.java:47`

- **Rule:** `dt074.java.sqli.tainted-jdbc` (semgrep, taint, confidence HIGH)
- **Why it blocks:** OWASP risk CRITICAL with confirmed source-to-sink data flow, confidence HIGH
- **Risk:** Attacker-controlled text is concatenated into an SQL statement, so it can change the query's meaning (read/modify/delete any row).
- **Also reported by:** `formatted-sql-string` (L47), `tainted-sql-from-http-request` (L38) — merged into one issue
- **Detail:** Untrusted input from '"name"' reaches a JDBC query string. Use a PreparedStatement with '?' placeholders and bind the value with setString().

```java
  45 | 
  46 |             /* POTENTIAL FLAW: data concatenated into SQL statement used in executeQuery(), which could result in SQL Injection */
> 47 |             resultSet = sqlStatement.executeQuery("select * from users where name='"+data+"'");
  48 | 
  49 |             IO.writeLine(resultSet.getRow()); /* Use ResultSet in some way */
```

**How to fix (java):**

```java
// Bind the value; never concatenate it into the SQL text.
try (PreparedStatement ps = conn.prepareStatement(
        "select * from users where name = ?")) {
    ps.setString(1, name);
    try (ResultSet rs = ps.executeQuery()) { /* ... */ }
}
```

References: https://cwe.mitre.org/data/definitions/89.html · https://cheatsheetseries.owasp.org/cheatsheets/Query_Parameterization_Cheat_Sheet.html

<details><summary>6 advisory finding(s) — not blocking</summary>

| Severity | Tool | Location | Rule | Why not blocking |
|---|---|---|---|---|
| HIGH | semgrep | `app/python/service.py:28` | `directly-returned-format-string` | value passes through a known sanitiser on the reported line |
| HIGH | semgrep | `app/python/service.py:28` | `raw-html-format` | value passes through a known sanitiser on the reported line |
| MEDIUM | semgrep | `app/python/service.py:28` | `raw-html-format` | OWASP risk MEDIUM (likelihood MEDIUM x impact MEDIUM) below HIGH |
| HIGH | trivy | `app/java/pom.xml:1` | `CVE-2026-42198` | package is not imported by in-scope code |
| HIGH | trivy | `app/java/pom.xml:1` | `CVE-2026-54291` | package is not imported by in-scope code |
| LOW | trivy | `app/python/requirements.txt:1` | `CVE-2026-27205` | CVE severity LOW below HIGH |

</details>

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 6 | 8.92 | 243 |
| gitleaks | ok | 0 | 0.57 | 63 |
| syft | ok | 0 | 1.66 | 188 |
| trivy | ok | 3 | 0.10 | 106 |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
