# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (1 findings) · 0 advisory · scope: 1 changed file(s) (`a1bf0b245f..77eb88975e`) · 5.2s · policy `adaptive-no_risk_threshold` v1

## Blocking issues — fix before merge

### 1. [MEDIUM] Broken or Risky Cryptographic Algorithm — CWE-327 — `app/java/src/main/java/edu/demo/CWE321_Hard_Coded_Cryptographic_Key__basic_01_good.java:64`

- **Rule:** `java.lang.security.audit.crypto.use-of-default-aes.use-of-default-aes` (semgrep, pattern, confidence HIGH)
- **Why it blocks:** OWASP risk MEDIUM, confidence HIGH
- **Risk:** Cipher.getInstance("AES") defaults to ECB mode, which leaks plaintext patterns.
- **Detail:** Use of AES with no settings detected. By default, java.crypto.Cipher uses ECB mode. ECB doesn't provide message confidentiality and is not semantically secure so should not be used. Instead, use a strong, secure cipher: java.crypto.Cipher.getInstance("AES/CBC/PKCS7PADDING"). See https://owasp.org/www-community/Using_the_Java_Cryptographic_Extensions for more information.

```java
  62 |             /* POTENTIAL FLAW: Use data as a cryptographic key */
  63 |             SecretKeySpec secretKeySpec = new SecretKeySpec(data.getBytes("UTF-8"), "AES");
> 64 |             Cipher aesCipher = Cipher.getInstance("AES");
  65 |             aesCipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);
  66 |             byte[] byteCipherText = aesCipher.doFinal(byteStringToEncrypt);
```

**How to fix (java):**

```java
Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
c.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(128, iv));
```

References: https://cwe.mitre.org/data/definitions/327.html · https://owasp.org/Top10/A02_2021-Cryptographic_Failures

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 1 | 4.63 | 188 |
| gitleaks | ok | 0 | 0.50 | 59 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
