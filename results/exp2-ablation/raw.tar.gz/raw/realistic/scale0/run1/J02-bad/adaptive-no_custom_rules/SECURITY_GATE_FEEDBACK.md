# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (2 findings) · 0 advisory · scope: 1 changed file(s) (`1a68668c14..193f2c370f`) · 5.7s · policy `adaptive-no_custom_rules` v1

## Blocking issues — fix before merge

### 1. [HIGH] SQL Injection — CWE-89 — `app/java/src/main/java/edu/demo/CWE89_SQL_Injection__getCookies_Servlet_executeUpdate_01_bad.java:47`

- **Rule:** `java.lang.security.audit.sqli.tainted-sql-from-http-request.tainted-sql-from-http-request` (semgrep, taint, confidence HIGH)
- **Why it blocks:** OWASP risk HIGH with confirmed source-to-sink data flow, confidence HIGH
- **Risk:** Attacker-controlled text is concatenated into an SQL statement, so it can change the query's meaning (read/modify/delete any row).
- **Also reported by:** `formatted-sql-string` (L55) — merged into one issue
- **Detail:** Detected input from a HTTPServletRequest going into a SQL sink or statement. This could lead to SQL injection if variables in the SQL statement are not properly sanitized. Use parameterized SQL queries or properly sanitize user input instead.

```java
  45 | 
  46 |         Connection dbConnection = null;
> 47 |         Statement sqlStatement = null;
> 48 | 
> 49 |         try
> 50 |         {
  51 |             dbConnection = IO.getDBConnection();
  52 |             sqlStatement = dbConnection.createStatement();
```

**How to fix (java):**

```java
// Bind the value; never concatenate it into the SQL text.
try (PreparedStatement ps = conn.prepareStatement(
        "select * from users where name = ?")) {
    ps.setString(1, name);
    try (ResultSet rs = ps.executeQuery()) { /* ... */ }
}
```

References: https://cwe.mitre.org/data/definitions/89.html · https://cheatsheetseries.owasp.org/cheatsheets/Query_Parameterization_Cheat_Sheet.html · https://cheatsheetseries.owasp.org/cheatsheets/SQL_Injection_Prevention_Cheat_Sheet.html

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 2 | 5.15 | 188 |
| gitleaks | ok | 0 | 0.51 | 61 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
