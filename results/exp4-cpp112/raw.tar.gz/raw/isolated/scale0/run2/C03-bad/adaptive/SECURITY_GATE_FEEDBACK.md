# 🔒 Security Gate: ✅ PASSED

**0 blocking issue(s)** (0 findings) · 1 advisory · scope: 1 changed file(s) (`b721d369b8..b8979788f4`) · 4.2s · policy `adaptive` v1

<details><summary>1 advisory finding(s) — not blocking</summary>

| Severity | Tool | Location | Rule | Why not blocking |
|---|---|---|---|---|
| LOW | semgrep | `app/c/src/CWE78_OS_Command_Injection__char_connect_socket_system_01_bad.c:85` | `insecure-use-memset` | audit-grade rule (not a confirmed vulnerability) |

</details>

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 1 | 3.64 | 181 |
| gitleaks | ok | 0 | 0.52 | 62 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |
