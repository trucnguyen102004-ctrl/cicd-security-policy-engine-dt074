# 🔒 Security Gate: ✅ PASSED

**0 blocking issue(s)** (0 findings) · 1 advisory · scope: 1 changed file(s) (`4be0e8d3b4..4a0960b581`) · 4.5s · policy `adaptive` v1

<details><summary>1 advisory finding(s) — not blocking</summary>

| Severity | Tool | Location | Rule | Why not blocking |
|---|---|---|---|---|
| MEDIUM | semgrep | `app/c/src/CWE259_Hard_Coded_Password__w32_char_01_bad.c:33` | `insecure-use-string-copy-fn` | audit-grade rule (not a confirmed vulnerability) |

</details>

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 1 | 3.81 | 181 |
| gitleaks | ok | 0 | 0.59 | 62 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |
