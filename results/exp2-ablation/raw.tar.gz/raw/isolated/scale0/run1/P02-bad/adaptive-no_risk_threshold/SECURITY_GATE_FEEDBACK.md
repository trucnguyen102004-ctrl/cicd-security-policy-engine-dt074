# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (3 findings) · 0 advisory · scope: 1 changed file(s) (`a4cedbedc7..16e66c0bff`) · 7.2s · policy `adaptive-no_risk_threshold` v1

## Blocking issues — fix before merge

### 1. [HIGH] Cross-site Scripting (XSS) — CWE-79 — `app/python/CWE79_XSS__flask_args_response_01_bad.py:16`

- **Rule:** `dt074.python.xss.tainted-flask-response` (semgrep, taint, confidence HIGH)
- **Why it blocks:** OWASP risk HIGH with confirmed source-to-sink data flow, confidence HIGH
- **Risk:** Request data is written into an HTML response without output encoding, so a crafted value runs JavaScript in the victim's browser.
- **Also reported by:** `raw-html-format` (L16) — merged into one issue
- **Detail:** Untrusted request data is returned as HTML without encoding. Use markupsafe.escape() or render a Jinja2 template with autoescaping.

```python
  14 |     data = request.args.get("name")
  15 |     # POTENTIAL FLAW: display of data in web page without any encoding
> 16 |     return make_response("<br>bad(): data = " + data)
```

**How to fix (python):**

```python
from markupsafe import escape
return make_response("<br>data = " + escape(data))
# or render_template(...) with Jinja2 autoescaping (default in Flask)
```

References: https://cwe.mitre.org/data/definitions/79.html · https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 3 | 6.61 | 211 |
| gitleaks | ok | 0 | 0.49 | 60 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
