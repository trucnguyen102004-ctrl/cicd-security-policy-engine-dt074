# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (2 findings) · 0 advisory · scope: 1 changed file(s) (`73a6a7739e..b682edbb49`) · 7.3s · policy `adaptive-no_custom_rules` v1

## Blocking issues — fix before merge

### 1. [HIGH] Hard-coded Credentials / Secrets — CWE-798 — `app/python/CWE798_Hard_Coded_Credentials__jwt_secret_01_bad.py:16`

- **Rule:** `python.jwt.security.jwt-hardcode.jwt-python-hardcoded-secret` (semgrep, pattern, confidence HIGH)
- **Why it blocks:** OWASP risk HIGH, confidence HIGH
- **Risk:** Anyone with read access to the repository (or its history, forks, CI logs) obtains the credential. Removing it from the latest commit is not enough.
- **Also reported by:** `generic-api-key` (L10) — merged into one issue
- **Detail:** Hardcoded JWT secret or private key is used. This is a Insufficiently Protected Credentials weakness: https://cwe.mitre.org/data/definitions/522.html Consider using an appropriate security mechanism to protect the credentials (e.g. keeping secrets in environment variables)

```python
  14 |     payload = {"sub": user_id,
  15 |                "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=1)}
> 16 |     return jwt.encode(payload, api_secret_key, algorithm="HS256")
```

**How to fix (python):**

```python
import os
secret = os.environ["JWT_SIGNING_KEY"]            # or a secret manager client
```

1. **Rotate/revoke the exposed value now** — it is already in git history.
2. Store it in GitHub Actions secrets / Vault / cloud secret manager.
3. If needed, purge history with `git filter-repo` after rotation.

References: https://cwe.mitre.org/data/definitions/798.html · https://cheatsheetseries.owasp.org/cheatsheets/Secrets_Management_Cheat_Sheet.html · https://semgrep.dev/blog/2020/hardcoded-secrets-unverified-tokens-and-other-common-jwt-mistakes/

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 1 | 6.64 | 250 |
| gitleaks | ok | 1 | 0.54 | 61 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
