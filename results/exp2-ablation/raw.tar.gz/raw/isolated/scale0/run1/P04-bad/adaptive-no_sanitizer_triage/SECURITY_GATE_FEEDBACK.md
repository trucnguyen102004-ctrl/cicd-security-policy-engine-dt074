# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (3 findings) · 0 advisory · scope: 1 changed file(s) (`73a6a7739e..b682edbb49`) · 7.3s · policy `adaptive-no_sanitizer_triage` v1

## Blocking issues — fix before merge

### 1. [CRITICAL] Hard-coded Credentials / Secrets — CWE-798 — `app/python/CWE798_Hard_Coded_Credentials__jwt_secret_01_bad.py:10`

- **Rule:** `dt074.python.secrets.hardcoded-credential-variable` (semgrep, pattern, confidence MEDIUM)
- **Why it blocks:** OWASP risk CRITICAL, confidence MEDIUM
- **Risk:** Anyone with read access to the repository (or its history, forks, CI logs) obtains the credential. Removing it from the latest commit is not enough.
- **Also reported by:** `generic-api-key` (L10), `jwt-python-hardcoded-secret` (L16) — merged into one issue
- **Detail:** 'api_secret_key' is assigned a high-entropy string literal that looks like a credential. Read it from os.environ or a secret manager and rotate it.

```python
   8 | 
   9 | # FLAW: signing secret hard-coded in source
> 10 | api_secret_key = "Zq8v********"
  11 | 
  12 | 
```

**How to fix (python):**

```python
import os
secret = os.environ["JWT_SIGNING_KEY"]            # or a secret manager client
```

1. **Rotate/revoke the exposed value now** — it is already in git history.
2. Store it in GitHub Actions secrets / Vault / cloud secret manager.
3. If needed, purge history with `git filter-repo` after rotation.

References: https://cwe.mitre.org/data/definitions/798.html · https://cheatsheetseries.owasp.org/cheatsheets/Secrets_Management_Cheat_Sheet.html

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 2 | 6.65 | 251 |
| gitleaks | ok | 1 | 0.52 | 59 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
