# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (3 findings) · 0 advisory · scope: 1 changed file(s) (`59131d0b75..452f180459`) · 5.0s · policy `adaptive` v1

## Blocking issues — fix before merge

### 1. [CRITICAL] SQL Injection — CWE-89 — `app/java/src/main/java/edu/demo/CWE89_SQL_Injection__getParameter_Servlet_executeUpdate_03_bad.java:54`

- **Rule:** `dt074.java.sqli.tainted-jdbc` (semgrep, taint, confidence HIGH)
- **Why it blocks:** OWASP risk CRITICAL with confirmed source-to-sink data flow, confidence HIGH
- **Risk:** Attacker-controlled text is concatenated into an SQL statement, so it can change the query's meaning (read/modify/delete any row).
- **Also reported by:** `formatted-sql-string` (L54), `tainted-sql-from-http-request` (L48) — merged into one issue
- **Detail:** Untrusted input from '"name"' reaches a JDBC query string. Use a PreparedStatement with '?' placeholders and bind the value with setString().

```java
  52 |                 sqlStatement = dbConnection.createStatement();
  53 |                 /* POTENTIAL FLAW: data concatenated into SQL statement used in executeUpdate(), which could result in SQL Injection */
> 54 |                 int rowCount = sqlStatement.executeUpdate("insert into users (status) values ('updated') where name='"+data+"'");
  55 |                 IO.writeLine("Updated " + rowCount + " rows successfully.");
  56 |             }
```

**How to fix (java):**

```java
// Bind the value; never concatenate it into the SQL text.
try (PreparedStatement ps = conn.prepareStatement(
        "select * from users where name = ?")) {
    ps.setString(1, name);
    try (ResultSet rs = ps.executeQuery()) { /* ... */ }
}
```

References: https://cwe.mitre.org/data/definitions/89.html · https://cheatsheetseries.owasp.org/cheatsheets/Query_Parameterization_Cheat_Sheet.html

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 3 | 4.47 | 187 |
| gitleaks | ok | 0 | 0.49 | 61 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
