# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (4 findings) · 6 advisory · scope: 5 changed file(s) (`..46f18b48a4`) · 10.7s · policy `adaptive-no_differential` v1

## Blocking issues — fix before merge

### 1. [CRITICAL] Path Traversal — CWE-22 — `app/java/src/main/java/edu/demo/CWE36_Absolute_Path_Traversal__getParameter_Servlet_02_bad.java:47`

- **Rule:** `dt074.java.path.tainted-file-access` (semgrep, taint, confidence HIGH)
- **Why it blocks:** OWASP risk CRITICAL with confirmed source-to-sink data flow, confidence HIGH
- **Risk:** A user-supplied value controls a file path, so '../' or an absolute path can read or overwrite files outside the intended directory.
- **Also reported by:** `httpservlet-path-traversal` (L47), `httpservlet-path-traversal` (L55), `tainted-file-access` (L55) — merged into one issue
- **Detail:** Untrusted input from '"name"' controls a filesystem path. Canonicalise the path and verify it stays under the allowed base directory, or keep only the file name (FilenameUtils.getName).

```java
  45 |         if (data != null)
  46 |         {
> 47 |             File file = new File(data);
  48 |             FileInputStream streamFileInputSink = null;
  49 |             InputStreamReader readerInputStreamSink = null;
```

**How to fix (java):**

```java
Path base = Paths.get("/srv/uploads").toRealPath();
Path target = base.resolve(userName).normalize();
if (!target.startsWith(base)) {
    throw new SecurityException("path escapes upload directory");
}
```

References: https://cwe.mitre.org/data/definitions/22.html · https://owasp.org/www-community/attacks/Path_Traversal

<details><summary>6 advisory finding(s) — not blocking</summary>

| Severity | Tool | Location | Rule | Why not blocking |
|---|---|---|---|---|
| HIGH | semgrep | `app/python/service.py:28` | `directly-returned-format-string` | value passes through a known sanitiser on the reported line |
| HIGH | semgrep | `app/python/service.py:28` | `raw-html-format` | value passes through a known sanitiser on the reported line |
| MEDIUM | semgrep | `app/python/service.py:28` | `raw-html-format` | OWASP risk MEDIUM (likelihood MEDIUM x impact MEDIUM) below HIGH |
| HIGH | trivy | `app/java/pom.xml:1` | `CVE-2026-42198` | package is not imported by in-scope code |
| HIGH | trivy | `app/java/pom.xml:1` | `CVE-2026-54291` | package is not imported by in-scope code |
| LOW | trivy | `app/python/requirements.txt:1` | `CVE-2026-27205` | CVE severity LOW below HIGH |

</details>

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 7 | 8.49 | 249 |
| gitleaks | ok | 0 | 0.52 | 66 |
| syft | ok | 0 | 1.44 | 188 |
| trivy | ok | 3 | 0.09 | 103 |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
