# 🔒 Security Gate: ❌ BLOCKED

**2 blocking issue(s)** (2 findings) · 0 advisory · scope: 1 changed file(s) (`c52970247d..dd1b5c13a4`) · 5.7s · policy `adaptive-no_risk_threshold` v1

## Blocking issues — fix before merge

### 1. [CRITICAL] Hard-coded Credentials / Secrets — CWE-798 — `app/java/src/main/java/edu/demo/CWE321_Hard_Coded_Cryptographic_Key__basic_01_bad.java:44`

- **Rule:** `dt074.java.secrets.hardcoded-credential` (semgrep, pattern, confidence HIGH)
- **Why it blocks:** OWASP risk CRITICAL, confidence HIGH
- **Risk:** Anyone with read access to the repository (or its history, forks, CI logs) obtains the credential. Removing it from the latest commit is not enough.
- **Detail:** A string literal is used as a credential or cryptographic key. Load it at runtime from a secret manager or environment variable and rotate the exposed value.

```java
  42 |             byte[] byteStringToEncrypt = stringToEncrypt.getBytes("UTF-8");
  43 |             /* POTENTIAL FLAW: Use data as a cryptographic key */
> 44 |             SecretKeySpec secretKeySpec = new SecretKeySpec(data.getBytes("UTF-8"), "AES");
  45 |             Cipher aesCipher = Cipher.getInstance("AES");
  46 |             aesCipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);
```

**How to fix (java):**

```java
String password = System.getenv("DB_PASSWORD");   // injected by the platform
Connection c = DriverManager.getConnection(url, user, password);
```

1. **Rotate/revoke the exposed value now** — it is already in git history.
2. Store it in GitHub Actions secrets / Vault / cloud secret manager.
3. If needed, purge history with `git filter-repo` after rotation.

References: https://cwe.mitre.org/data/definitions/798.html · https://cheatsheetseries.owasp.org/cheatsheets/Secrets_Management_Cheat_Sheet.html

### 2. [MEDIUM] Broken or Risky Cryptographic Algorithm — CWE-327 — `app/java/src/main/java/edu/demo/CWE321_Hard_Coded_Cryptographic_Key__basic_01_bad.java:45`

- **Rule:** `java.lang.security.audit.crypto.use-of-default-aes.use-of-default-aes` (semgrep, pattern, confidence HIGH)
- **Why it blocks:** OWASP risk MEDIUM, confidence HIGH
- **Risk:** Cipher.getInstance("AES") defaults to ECB mode, which leaks plaintext patterns.
- **Detail:** Use of AES with no settings detected. By default, java.crypto.Cipher uses ECB mode. ECB doesn't provide message confidentiality and is not semantically secure so should not be used. Instead, use a strong, secure cipher: java.crypto.Cipher.getInstance("AES/CBC/PKCS7PADDING"). See https://owasp.org/www-community/Using_the_Java_Cryptographic_Extensions for more information.

```java
  43 |             /* POTENTIAL FLAW: Use data as a cryptographic key */
  44 |             SecretKeySpec secretKeySpec = new SecretKeySpec(data.getBytes("UTF-8"), "AES");
> 45 |             Cipher aesCipher = Cipher.getInstance("AES");
  46 |             aesCipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);
  47 |             byte[] byteCipherText = aesCipher.doFinal(byteStringToEncrypt);
```

**How to fix (java):**

```java
Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
c.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(128, iv));
```

References: https://cwe.mitre.org/data/definitions/327.html · https://owasp.org/Top10/A02_2021-Cryptographic_Failures

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 2 | 5.05 | 187 |
| gitleaks | ok | 0 | 0.55 | 59 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
