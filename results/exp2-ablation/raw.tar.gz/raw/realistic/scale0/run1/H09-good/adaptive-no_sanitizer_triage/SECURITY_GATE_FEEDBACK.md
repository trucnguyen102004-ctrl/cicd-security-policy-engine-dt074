# 🔒 Security Gate: ✅ PASSED

**0 blocking issue(s)** (0 findings) · 0 advisory · scope: 1 changed file(s) (`bd298e14ea..1ab23320a9`) · 5.2s · policy `adaptive-no_sanitizer_triage` v1

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 0 | 4.61 | 189 |
| gitleaks | ok | 0 | 0.51 | 63 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |
