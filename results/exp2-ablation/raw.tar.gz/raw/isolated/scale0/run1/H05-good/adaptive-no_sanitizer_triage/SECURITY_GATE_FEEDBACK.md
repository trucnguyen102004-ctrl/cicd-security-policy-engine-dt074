# 🔒 Security Gate: ✅ PASSED

**0 blocking issue(s)** (0 findings) · 0 advisory · scope: 1 changed file(s) (`26e9961e90..d81c7cd527`) · 5.2s · policy `adaptive-no_sanitizer_triage` v1

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 0 | 4.58 | 187 |
| gitleaks | ok | 0 | 0.49 | 61 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |
