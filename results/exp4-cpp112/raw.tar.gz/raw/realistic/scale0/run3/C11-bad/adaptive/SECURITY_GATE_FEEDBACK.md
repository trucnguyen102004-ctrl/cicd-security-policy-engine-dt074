# 🔒 Security Gate: ✅ PASSED

**0 blocking issue(s)** (0 findings) · 1 advisory · scope: 1 changed file(s) (`b51bbad4bc..3d7f99e645`) · 4.3s · policy `adaptive` v1

<details><summary>1 advisory finding(s) — not blocking</summary>

| Severity | Tool | Location | Rule | Why not blocking |
|---|---|---|---|---|
| MEDIUM | semgrep | `app/c/src/CWE321_Hard_Coded_Cryptographic_Key__w32_char_01_bad.c:34` | `insecure-use-string-copy-fn` | audit-grade rule (not a confirmed vulnerability) |

</details>

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 1 | 3.66 | 182 |
| gitleaks | ok | 0 | 0.59 | 61 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |
