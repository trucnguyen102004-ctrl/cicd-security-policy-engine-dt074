# 🔒 Security Gate: ✅ PASSED

**0 blocking issue(s)** (0 findings) · 0 advisory · scope: 1 changed file(s) (`76b83e7660..18a415b5c7`) · 5.6s · policy `adaptive-no_sanitizer_triage` v1

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 0 | 4.98 | 189 |
| gitleaks | ok | 0 | 0.51 | 61 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |
