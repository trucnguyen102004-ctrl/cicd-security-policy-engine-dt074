# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (1 findings) · 1 advisory · scope: 1 changed file(s) (`baaca24e29..72e3b883ef`) · 7.3s · policy `adaptive` v1

## Blocking issues — fix before merge

### 1. [CRITICAL] SQL Injection — CWE-89 — `app/python/CWE89_SQL_Injection__flask_args_execute_01_bad.py:19`

- **Rule:** `dt074.python.sqli.tainted-dbapi` (semgrep, taint, confidence HIGH)
- **Why it blocks:** OWASP risk CRITICAL with confirmed source-to-sink data flow, confidence HIGH
- **Risk:** Attacker-controlled text is concatenated into an SQL statement, so it can change the query's meaning (read/modify/delete any row).
- **Detail:** Untrusted request data reaches a DB-API query string. Pass values as parameters: cur.execute("... WHERE name = ?", (name,)).

```python
  17 |     cur = conn.cursor()
  18 |     # POTENTIAL FLAW: data concatenated into SQL statement
> 19 |     cur.execute("select * from users where name='" + data + "'")
  20 |     return str(cur.fetchall())
```

**How to fix (python):**

```python
# DB-API parameter binding (sqlite3 uses ?, psycopg uses %s)
cur.execute("select * from users where name = ?", (name,))
```

References: https://cwe.mitre.org/data/definitions/89.html · https://cheatsheetseries.owasp.org/cheatsheets/Query_Parameterization_Cheat_Sheet.html

<details><summary>1 advisory finding(s) — not blocking</summary>

| Severity | Tool | Location | Rule | Why not blocking |
|---|---|---|---|---|
| MEDIUM | semgrep | `app/python/CWE89_SQL_Injection__flask_args_execute_01_bad.py:19` | `tainted-sql-string` | OWASP risk MEDIUM (likelihood MEDIUM x impact MEDIUM) below HIGH |

</details>

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 2 | 6.69 | 255 |
| gitleaks | ok | 0 | 0.50 | 60 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
