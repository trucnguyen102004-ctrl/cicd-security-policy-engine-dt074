# 🔒 Security Gate: ✅ PASSED

**0 blocking issue(s)** (0 findings) · 0 advisory · scope: 2 changed file(s) (`77dff24d17..14c2af1392`) · 9.7s · policy `adaptive-no_sanitizer_triage` v1

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 0 | 7.39 | 256 |
| gitleaks | ok | 0 | 0.57 | 61 |
| syft | ok | 0 | 1.50 | 174 |
| trivy | ok | 0 | 0.10 | 103 |
