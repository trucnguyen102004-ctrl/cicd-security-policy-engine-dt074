# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (4 findings) · 0 advisory · scope: 1 changed file(s) (`e41c2d93b6..26a1f934df`) · 5.6s · policy `adaptive-no_risk_threshold` v1

## Blocking issues — fix before merge

### 1. [CRITICAL] Path Traversal — CWE-22 — `app/java/src/main/java/edu/demo/CWE36_Absolute_Path_Traversal__getParameter_Servlet_02_bad.java:47`

- **Rule:** `dt074.java.path.tainted-file-access` (semgrep, taint, confidence HIGH)
- **Why it blocks:** OWASP risk CRITICAL with confirmed source-to-sink data flow, confidence HIGH
- **Risk:** A user-supplied value controls a file path, so '../' or an absolute path can read or overwrite files outside the intended directory.
- **Also reported by:** `httpservlet-path-traversal` (L47), `httpservlet-path-traversal` (L55), `tainted-file-access` (L55) — merged into one issue
- **Detail:** Untrusted input from '"name"' controls a filesystem path. Canonicalise the path and verify it stays under the allowed base directory, or keep only the file name (FilenameUtils.getName).

```java
  45 |         if (data != null)
  46 |         {
> 47 |             File file = new File(data);
  48 |             FileInputStream streamFileInputSink = null;
  49 |             InputStreamReader readerInputStreamSink = null;
```

**How to fix (java):**

```java
Path base = Paths.get("/srv/uploads").toRealPath();
Path target = base.resolve(userName).normalize();
if (!target.startsWith(base)) {
    throw new SecurityException("path escapes upload directory");
}
```

References: https://cwe.mitre.org/data/definitions/22.html · https://owasp.org/www-community/attacks/Path_Traversal

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 4 | 5.00 | 189 |
| gitleaks | ok | 0 | 0.55 | 61 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
