# 🔒 Security Gate: ✅ PASSED

**0 blocking issue(s)** (0 findings) · 1 advisory · scope: 1 changed file(s) (`ec4e1058c6..3a08be724f`) · 4.5s · policy `adaptive` v1

<details><summary>1 advisory finding(s) — not blocking</summary>

| Severity | Tool | Location | Rule | Why not blocking |
|---|---|---|---|---|
| MEDIUM | semgrep | `app/c/src/CWE321_Hard_Coded_Cryptographic_Key__w32_char_01_bad.c:34` | `insecure-use-string-copy-fn` | audit-grade rule (not a confirmed vulnerability) |

</details>

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 1 | 3.69 | 180 |
| gitleaks | ok | 0 | 0.71 | 62 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |
