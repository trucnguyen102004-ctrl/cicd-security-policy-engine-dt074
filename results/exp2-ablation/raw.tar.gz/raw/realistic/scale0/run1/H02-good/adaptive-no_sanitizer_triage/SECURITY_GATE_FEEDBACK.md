# 🔒 Security Gate: ✅ PASSED

**0 blocking issue(s)** (0 findings) · 0 advisory · scope: 1 changed file(s) (`08a3a9b2d4..78f71f5422`) · 5.8s · policy `adaptive-no_sanitizer_triage` v1

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 0 | 5.18 | 187 |
| gitleaks | ok | 0 | 0.51 | 62 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |
