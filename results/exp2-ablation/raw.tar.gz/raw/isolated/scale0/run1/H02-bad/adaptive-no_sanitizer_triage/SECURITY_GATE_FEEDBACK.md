# 🔒 Security Gate: ✅ PASSED

**0 blocking issue(s)** (0 findings) · 0 advisory · scope: 1 changed file(s) (`5a89440f54..3f9f95bf4b`) · 5.5s · policy `adaptive-no_sanitizer_triage` v1

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 0 | 4.87 | 189 |
| gitleaks | ok | 0 | 0.57 | 60 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |
