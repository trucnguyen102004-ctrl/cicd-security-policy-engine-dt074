# 🔒 Security Gate: ✅ PASSED

**0 blocking issue(s)** (0 findings) · 1 advisory · scope: 1 changed file(s) (`25199d306c..e90a2ef94f`) · 4.9s · policy `adaptive` v1

<details><summary>1 advisory finding(s) — not blocking</summary>

| Severity | Tool | Location | Rule | Why not blocking |
|---|---|---|---|---|
| MEDIUM | semgrep | `app/java/src/main/java/edu/demo/CWE321_Hard_Coded_Cryptographic_Key__basic_01_good.java:64` | `use-of-default-aes` | OWASP risk MEDIUM (likelihood MEDIUM x impact MEDIUM) below HIGH |

</details>

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 1 | 4.39 | 189 |
| gitleaks | ok | 0 | 0.48 | 60 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |
