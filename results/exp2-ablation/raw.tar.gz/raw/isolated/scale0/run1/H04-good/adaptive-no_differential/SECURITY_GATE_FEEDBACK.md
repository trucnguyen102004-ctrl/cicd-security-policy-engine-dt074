# 🔒 Security Gate: ✅ PASSED

**0 blocking issue(s)** (0 findings) · 0 advisory · scope: 1 changed file(s) (`..47f2b1442d`) · 10.8s · policy `adaptive-no_differential` v1

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 0 | 8.68 | 259 |
| gitleaks | ok | 0 | 0.51 | 61 |
| syft | ok | 0 | 1.45 | 186 |
| trivy | ok | 0 | 0.09 | 103 |
