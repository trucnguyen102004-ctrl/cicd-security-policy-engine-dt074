# 🔒 Security Gate: ❌ BLOCKED

**2 blocking issue(s)** (2 findings) · 0 advisory · scope: 1 changed file(s) (`9f5ff2ae01..cfcbbe21a1`) · 7.4s · policy `adaptive-no_risk_threshold` v1

## Blocking issues — fix before merge

### 1. [CRITICAL] SQL Injection — CWE-89 — `app/python/CWE89_SQL_Injection__flask_args_execute_01_bad.py:19`

- **Rule:** `dt074.python.sqli.tainted-dbapi` (semgrep, taint, confidence HIGH)
- **Why it blocks:** OWASP risk CRITICAL with confirmed source-to-sink data flow, confidence HIGH
- **Risk:** Attacker-controlled text is concatenated into an SQL statement, so it can change the query's meaning (read/modify/delete any row).
- **Detail:** Untrusted request data reaches a DB-API query string. Pass values as parameters: cur.execute("... WHERE name = ?", (name,)).

```python
  17 |     cur = conn.cursor()
  18 |     # POTENTIAL FLAW: data concatenated into SQL statement
> 19 |     cur.execute("select * from users where name='" + data + "'")
  20 |     return str(cur.fetchall())
```

**How to fix (python):**

```python
# DB-API parameter binding (sqlite3 uses ?, psycopg uses %s)
cur.execute("select * from users where name = ?", (name,))
```

References: https://cwe.mitre.org/data/definitions/89.html · https://cheatsheetseries.owasp.org/cheatsheets/Query_Parameterization_Cheat_Sheet.html

### 2. [MEDIUM] Security finding — default — `app/python/CWE89_SQL_Injection__flask_args_execute_01_bad.py:19`

- **Rule:** `python.flask.security.injection.tainted-sql-string.tainted-sql-string` (semgrep, taint, confidence MEDIUM)
- **Why it blocks:** OWASP risk MEDIUM with confirmed source-to-sink data flow, confidence MEDIUM
- **Risk:** The rule reported a potential weakness; review the linked CWE for context.
- **Detail:** Detected user input used to manually construct a SQL string. This is usually bad practice because manual construction could accidentally result in a SQL injection. An attacker could use a SQL injection to steal or modify contents of the database. Instead, use a parameterized query which is available by default in most database engines. Alternatively, consider using an object-relational mapper (ORM) such as SQLAlchemy which will protect your queries.

```python
  17 |     cur = conn.cursor()
  18 |     # POTENTIAL FLAW: data concatenated into SQL statement
> 19 |     cur.execute("select * from users where name='" + data + "'")
  20 |     return str(cur.fetchall())
```

**How to fix (general):**

```text
Follow the rule message and the CWE reference below.
```

References: https://docs.sqlalchemy.org/en/14/core/tutorial.html#using-textual-sql

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 2 | 6.80 | 253 |
| gitleaks | ok | 0 | 0.53 | 61 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
