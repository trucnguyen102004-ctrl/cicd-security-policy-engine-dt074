# 🔒 Security Gate: ✅ PASSED

**0 blocking issue(s)** (0 findings) · 0 advisory · scope: 1 changed file(s) (`d06e49729f..b1f2f461e2`) · 5.5s · policy `adaptive-no_sanitizer_triage` v1

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 0 | 4.68 | 188 |
| gitleaks | ok | 0 | 0.67 | 58 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |
