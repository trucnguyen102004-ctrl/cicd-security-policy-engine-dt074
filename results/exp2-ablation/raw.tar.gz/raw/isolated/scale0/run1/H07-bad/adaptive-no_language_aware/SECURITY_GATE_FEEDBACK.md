# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (2 findings) · 0 advisory · scope: 1 changed file(s) (`7996c701e9..7215bafbe7`) · 9.4s · policy `adaptive-no_language_aware` v1

## Blocking issues — fix before merge

### 1. [HIGH] Cross-site Scripting (XSS) — CWE-79 — `app/java/src/main/java/edu/demo/CWE80_XSS__Servlet_getParameter_Servlet_03_bad.java:43`

- **Rule:** `dt074.java.xss.tainted-servlet-writer` (semgrep, taint, confidence HIGH)
- **Why it blocks:** OWASP risk HIGH with confirmed source-to-sink data flow, confidence HIGH
- **Risk:** Request data is written into an HTML response without output encoding, so a crafted value runs JavaScript in the victim's browser.
- **Also reported by:** `no-direct-response-writer` (L43) — merged into one issue
- **Detail:** Untrusted input from '"name"' is written to the HTTP response without HTML encoding. Encode it (OWASP Encoder Encode.forHtml / StringEscapeUtils.escapeHtml4).

```java
  41 |         {
  42 |             /* POTENTIAL FLAW: Display of data in web page without any encoding or validation */
> 43 |             response.getWriter().println("<br>bad(): data = " + data);
  44 |         }
  45 | 
```

**How to fix (java):**

```java
// OWASP Java Encoder: encode for the exact output context
import org.owasp.encoder.Encode;
response.getWriter().println("<br>data = " + Encode.forHtml(data));
```

References: https://cwe.mitre.org/data/definitions/79.html · https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 2 | 8.75 | 249 |
| gitleaks | ok | 0 | 0.53 | 60 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
