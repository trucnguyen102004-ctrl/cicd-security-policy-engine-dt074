# 🔒 Security Gate: ✅ PASSED

**0 blocking issue(s)** (0 findings) · 0 advisory · scope: 1 changed file(s) (`be579b8c47..db3d5592fa`) · 6.3s · policy `adaptive-no_sanitizer_triage` v1

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 0 | 5.61 | 187 |
| gitleaks | ok | 0 | 0.58 | 61 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |
