# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (1 findings) · 0 advisory · scope: 1 changed file(s) (`7996c701e9..7215bafbe7`) · 5.1s · policy `adaptive-no_custom_rules` v1

## Blocking issues — fix before merge

### 1. [HIGH] Cross-site Scripting (XSS) — CWE-79 — `app/java/src/main/java/edu/demo/CWE80_XSS__Servlet_getParameter_Servlet_03_bad.java:43`

- **Rule:** `java.lang.security.audit.xss.no-direct-response-writer.no-direct-response-writer` (semgrep, taint, confidence MEDIUM)
- **Why it blocks:** OWASP risk HIGH with confirmed source-to-sink data flow, confidence MEDIUM
- **Risk:** Request data is written into an HTML response without output encoding, so a crafted value runs JavaScript in the victim's browser.
- **Detail:** Detected a request with potential user-input going into a OutputStream or Writer object. This bypasses any view or template environments, including HTML escaping, which may expose this application to cross-site scripting (XSS) vulnerabilities. Consider using a view technology such as JavaServer Faces (JSFs) which automatically escapes HTML views.

```java
  41 |         {
  42 |             /* POTENTIAL FLAW: Display of data in web page without any encoding or validation */
> 43 |             response.getWriter().println("<br>bad(): data = " + data);
  44 |         }
  45 | 
```

**How to fix (java):**

```java
// OWASP Java Encoder: encode for the exact output context
import org.owasp.encoder.Encode;
response.getWriter().println("<br>data = " + Encode.forHtml(data));
```

References: https://cwe.mitre.org/data/definitions/79.html · https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html · https://www3.ntu.edu.sg/home/ehchua/programming/java/JavaServerFaces.html

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 1 | 4.48 | 188 |
| gitleaks | ok | 0 | 0.56 | 61 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
