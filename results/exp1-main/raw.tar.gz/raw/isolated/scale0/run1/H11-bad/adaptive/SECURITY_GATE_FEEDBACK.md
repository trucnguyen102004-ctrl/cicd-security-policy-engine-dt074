# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (1 findings) · 0 advisory · scope: 1 changed file(s) (`6f300aaade..eb42d03003`) · 5.3s · policy `adaptive` v1

## Blocking issues — fix before merge

### 1. [CRITICAL] Hard-coded Credentials / Secrets — CWE-798 — `app/java/src/main/java/edu/demo/CWE259_Hard_Coded_Password__kerberosKey_01_bad.java:40`

- **Rule:** `dt074.java.secrets.hardcoded-credential` (semgrep, pattern, confidence HIGH)
- **Why it blocks:** OWASP risk CRITICAL, confidence HIGH
- **Risk:** Anyone with read access to the repository (or its history, forks, CI logs) obtains the credential. Removing it from the latest commit is not enough.
- **Detail:** A string literal is used as a credential or cryptographic key. Load it at runtime from a secret manager or environment variable and rotate the exposed value.

```java
  38 |             KerberosPrincipal principal = new KerberosPrincipal("test");
  39 |             /* POTENTIAL FLAW: data used as password in KerberosKey() */
> 40 |             KerberosKey key = new KerberosKey(principal, data.toCharArray(), null);
  41 |             IO.writeLine(key.toString());
  42 |         }
```

**How to fix (java):**

```java
String password = System.getenv("DB_PASSWORD");   // injected by the platform
Connection c = DriverManager.getConnection(url, user, password);
```

1. **Rotate/revoke the exposed value now** — it is already in git history.
2. Store it in GitHub Actions secrets / Vault / cloud secret manager.
3. If needed, purge history with `git filter-repo` after rotation.

References: https://cwe.mitre.org/data/definitions/798.html · https://cheatsheetseries.owasp.org/cheatsheets/Secrets_Management_Cheat_Sheet.html

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 1 | 4.67 | 186 |
| gitleaks | ok | 0 | 0.51 | 61 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
