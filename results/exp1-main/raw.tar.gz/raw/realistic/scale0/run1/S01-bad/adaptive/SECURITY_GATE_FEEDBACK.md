# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (1 findings) · 0 advisory · scope: 2 changed file(s) (`1eadabc2b8..e4096583a9`) · 9.2s · policy `adaptive` v1

## Blocking issues — fix before merge

### 1. [CRITICAL] Security finding — default — `app/modules/S01_pyyaml_5.3.1_fullloader/requirements.txt`

- **Rule:** `CVE-2020-14343` (trivy, cve, confidence HIGH)
- **Why it blocks:** CRITICAL CVE introduced by this change
- **Risk:** The rule reported a potential weakness; review the linked CWE for context.
- **Detail:** pyyaml 5.3.1 is affected by CVE-2020-14343 (CRITICAL); fixed in 5.4

**How to fix (general):**

```text
Upgrade pyyaml 5.3.1 → 5.4
Follow the rule message and the CWE reference below.
```

References: https://avd.aquasec.com/nvd/cve-2020-14343

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 0 | 6.38 | 256 |
| gitleaks | ok | 0 | 0.48 | 61 |
| syft | ok | 0 | 2.19 | 179 |
| trivy | ok | 1 | 0.08 | 104 |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
