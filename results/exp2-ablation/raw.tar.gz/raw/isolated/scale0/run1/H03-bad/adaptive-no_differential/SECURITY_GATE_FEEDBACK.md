# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (3 findings) · 0 advisory · scope: 1 changed file(s) (`..c6a2ef14db`) · 10.6s · policy `adaptive-no_differential` v1

## Blocking issues — fix before merge

### 1. [CRITICAL] SQL Injection — CWE-89 — `app/java/src/main/java/edu/demo/CWE89_SQL_Injection__getParameter_Servlet_prepareStatement_02_bad.java:53`

- **Rule:** `dt074.java.sqli.tainted-jdbc` (semgrep, taint, confidence HIGH)
- **Why it blocks:** OWASP risk CRITICAL with confirmed source-to-sink data flow, confidence HIGH
- **Risk:** Attacker-controlled text is concatenated into an SQL statement, so it can change the query's meaning (read/modify/delete any row).
- **Also reported by:** `formatted-sql-string` (L54), `tainted-sql-from-http-request` (L53) — merged into one issue
- **Detail:** Untrusted input from '"name"' reaches a JDBC query string. Use a PreparedStatement with '?' placeholders and bind the value with setString().

```java
  51 |                 /* POTENTIAL FLAW: data concatenated into SQL statement used in prepareStatement() call, which could result in SQL Injection */
  52 |                 dbConnection = IO.getDBConnection();
> 53 |                 sqlStatement = dbConnection.prepareStatement("insert into users (status) values ('updated') where name='"+data+"'");
  54 |                 Boolean result = sqlStatement.execute();
  55 |                 if (result)
```

**How to fix (java):**

```java
// Bind the value; never concatenate it into the SQL text.
try (PreparedStatement ps = conn.prepareStatement(
        "select * from users where name = ?")) {
    ps.setString(1, name);
    try (ResultSet rs = ps.executeQuery()) { /* ... */ }
}
```

References: https://cwe.mitre.org/data/definitions/89.html · https://cheatsheetseries.owasp.org/cheatsheets/Query_Parameterization_Cheat_Sheet.html

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 3 | 8.33 | 258 |
| gitleaks | ok | 0 | 0.58 | 61 |
| syft | ok | 0 | 1.45 | 187 |
| trivy | ok | 0 | 0.07 | 103 |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
