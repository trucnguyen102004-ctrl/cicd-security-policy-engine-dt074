# 🔒 Security Gate: ✅ PASSED

**0 blocking issue(s)** (0 findings) · 6 advisory · scope: 5 changed file(s) (`..95cd0dff54`) · 11.3s · policy `adaptive-no_differential` v1

<details><summary>6 advisory finding(s) — not blocking</summary>

| Severity | Tool | Location | Rule | Why not blocking |
|---|---|---|---|---|
| HIGH | semgrep | `app/python/service.py:28` | `directly-returned-format-string` | value passes through a known sanitiser on the reported line |
| HIGH | semgrep | `app/python/service.py:28` | `raw-html-format` | value passes through a known sanitiser on the reported line |
| MEDIUM | semgrep | `app/python/service.py:28` | `raw-html-format` | OWASP risk MEDIUM (likelihood MEDIUM x impact MEDIUM) below HIGH |
| HIGH | trivy | `app/java/pom.xml:1` | `CVE-2026-42198` | package is not imported by in-scope code |
| HIGH | trivy | `app/java/pom.xml:1` | `CVE-2026-54291` | package is not imported by in-scope code |
| LOW | trivy | `app/python/requirements.txt:1` | `CVE-2026-27205` | CVE severity LOW below HIGH |

</details>

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 3 | 9.00 | 282 |
| gitleaks | ok | 0 | 0.57 | 65 |
| syft | ok | 0 | 1.51 | 186 |
| trivy | ok | 3 | 0.09 | 104 |
