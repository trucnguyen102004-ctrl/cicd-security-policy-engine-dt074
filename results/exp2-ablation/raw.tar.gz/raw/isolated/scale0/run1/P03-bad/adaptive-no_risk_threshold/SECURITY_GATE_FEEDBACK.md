# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (2 findings) · 0 advisory · scope: 1 changed file(s) (`23848d74c9..3a161b2dff`) · 7.6s · policy `adaptive-no_risk_threshold` v1

## Blocking issues — fix before merge

### 1. [CRITICAL] Path Traversal — CWE-22 — `app/python/CWE22_Path_Traversal__flask_args_open_01_bad.py:18`

- **Rule:** `dt074.python.path.tainted-open` (semgrep, taint, confidence HIGH)
- **Why it blocks:** OWASP risk CRITICAL with confirmed source-to-sink data flow, confidence HIGH
- **Risk:** A user-supplied value controls a file path, so '../' or an absolute path can read or overwrite files outside the intended directory.
- **Also reported by:** `path-traversal-open` (L18) — merged into one issue
- **Detail:** Untrusted request data controls a filesystem path. Reduce it to a bare file name with werkzeug.utils.secure_filename() or use flask.safe_join().

```python
  16 |     data = request.args.get("file")
  17 |     # POTENTIAL FLAW: no validation of concatenated path
> 18 |     with open(os.path.join(ROOT, data)) as fh:
  19 |         return fh.readline()
```

**How to fix (python):**

```python
from werkzeug.utils import secure_filename
path = os.path.join(UPLOAD_ROOT, secure_filename(name))
# or: flask.safe_join(UPLOAD_ROOT, name)  (returns None if unsafe)
```

References: https://cwe.mitre.org/data/definitions/22.html · https://owasp.org/www-community/attacks/Path_Traversal

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 2 | 7.03 | 253 |
| gitleaks | ok | 0 | 0.50 | 61 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
