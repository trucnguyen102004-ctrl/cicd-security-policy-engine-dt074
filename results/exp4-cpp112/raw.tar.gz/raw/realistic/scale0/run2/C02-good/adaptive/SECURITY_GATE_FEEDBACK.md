# 🔒 Security Gate: ✅ PASSED

**0 blocking issue(s)** (0 findings) · 1 advisory · scope: 1 changed file(s) (`f51b7867a2..b30498758c`) · 4.3s · policy `adaptive` v1

<details><summary>1 advisory finding(s) — not blocking</summary>

| Severity | Tool | Location | Rule | Why not blocking |
|---|---|---|---|---|
| MEDIUM | semgrep | `app/c/src/CWE78_OS_Command_Injection__char_console_popen_01_good.c:45` | `insecure-use-strcat-fn` | audit-grade rule (not a confirmed vulnerability) |

</details>

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 1 | 3.66 | 181 |
| gitleaks | ok | 0 | 0.56 | 61 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |
