# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (1 findings) · 0 advisory · scope: 1 changed file(s) (`0b34a57bf1..5a44d788ed`) · 5.1s · policy `adaptive` v1

## Blocking issues — fix before merge

### 1. [CRITICAL] SQL Injection — CWE-89 — `app/java/src/main/java/edu/demo/CWE89_SQL_Injection__Environment_execute_01_bad.java:46`

- **Rule:** `dt074.java.sqli.tainted-jdbc-nonweb` (semgrep, taint, confidence HIGH)
- **Why it blocks:** OWASP risk CRITICAL with confirmed source-to-sink data flow, confidence HIGH
- **Risk:** Attacker-controlled text is concatenated into an SQL statement, so it can change the query's meaning (read/modify/delete any row).
- **Detail:** Data read from '"ADD"' (environment or I/O stream) reaches a JDBC query string. Treat it as untrusted: use a PreparedStatement with bound parameters.

```java
  44 | 
  45 |             /* POTENTIAL FLAW: data concatenated into SQL statement used in execute(), which could result in SQL Injection */
> 46 |             Boolean result = sqlStatement.execute("insert into users (status) values ('updated') where name='"+data+"'");
  47 | 
  48 |             if(result)
```

**How to fix (java):**

```java
// Bind the value; never concatenate it into the SQL text.
try (PreparedStatement ps = conn.prepareStatement(
        "select * from users where name = ?")) {
    ps.setString(1, name);
    try (ResultSet rs = ps.executeQuery()) { /* ... */ }
}
```

References: https://cwe.mitre.org/data/definitions/89.html · https://cheatsheetseries.owasp.org/cheatsheets/Query_Parameterization_Cheat_Sheet.html

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 1 | 4.55 | 188 |
| gitleaks | ok | 0 | 0.49 | 60 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
