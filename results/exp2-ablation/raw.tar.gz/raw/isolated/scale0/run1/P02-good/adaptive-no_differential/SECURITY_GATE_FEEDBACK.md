# 🔒 Security Gate: ✅ PASSED

**0 blocking issue(s)** (0 findings) · 2 advisory · scope: 1 changed file(s) (`..3ba4de9417`) · 10.6s · policy `adaptive-no_differential` v1

<details><summary>2 advisory finding(s) — not blocking</summary>

| Severity | Tool | Location | Rule | Why not blocking |
|---|---|---|---|---|
| HIGH | semgrep | `app/python/CWE79_XSS__flask_args_response_01_good.py:23` | `raw-html-format` | value passes through a known sanitiser on the reported line |
| MEDIUM | semgrep | `app/python/CWE79_XSS__flask_args_response_01_good.py:23` | `raw-html-format` | OWASP risk MEDIUM (likelihood MEDIUM x impact MEDIUM) below HIGH |

</details>

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 2 | 8.32 | 243 |
| gitleaks | ok | 0 | 0.56 | 62 |
| syft | ok | 0 | 1.54 | 176 |
| trivy | ok | 0 | 0.09 | 104 |
