# 🔒 Security Gate: ✅ PASSED

**0 blocking issue(s)** (0 findings) · 2 advisory · scope: 1 changed file(s) (`0d7c50962a..3ba4de9417`) · 8.3s · policy `adaptive-no_risk_threshold` v1

<details><summary>2 advisory finding(s) — not blocking</summary>

| Severity | Tool | Location | Rule | Why not blocking |
|---|---|---|---|---|
| HIGH | semgrep | `app/python/CWE79_XSS__flask_args_response_01_good.py:23` | `raw-html-format` | value passes through a known sanitiser on the reported line |
| MEDIUM | semgrep | `app/python/CWE79_XSS__flask_args_response_01_good.py:23` | `raw-html-format` | value passes through a known sanitiser on the reported line |

</details>

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 2 | 7.64 | 251 |
| gitleaks | ok | 0 | 0.56 | 60 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |
