# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (1 findings) · 1 advisory · scope: 1 changed file(s) (`74487c37f6..f79817ff77`) · 5.0s · policy `adaptive` v1

## Blocking issues — fix before merge

### 1. [CRITICAL] Hard-coded Credentials / Secrets — CWE-798 — `app/java/src/main/java/edu/demo/CWE321_Hard_Coded_Cryptographic_Key__basic_01_bad.java:44`

- **Rule:** `dt074.java.secrets.hardcoded-credential` (semgrep, pattern, confidence HIGH)
- **Why it blocks:** OWASP risk CRITICAL, confidence HIGH
- **Risk:** Anyone with read access to the repository (or its history, forks, CI logs) obtains the credential. Removing it from the latest commit is not enough.
- **Detail:** A string literal is used as a credential or cryptographic key. Load it at runtime from a secret manager or environment variable and rotate the exposed value.

```java
  42 |             byte[] byteStringToEncrypt = stringToEncrypt.getBytes("UTF-8");
  43 |             /* POTENTIAL FLAW: Use data as a cryptographic key */
> 44 |             SecretKeySpec secretKeySpec = new SecretKeySpec(data.getBytes("UTF-8"), "AES");
  45 |             Cipher aesCipher = Cipher.getInstance("AES");
  46 |             aesCipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);
```

**How to fix (java):**

```java
String password = System.getenv("DB_PASSWORD");   // injected by the platform
Connection c = DriverManager.getConnection(url, user, password);
```

1. **Rotate/revoke the exposed value now** — it is already in git history.
2. Store it in GitHub Actions secrets / Vault / cloud secret manager.
3. If needed, purge history with `git filter-repo` after rotation.

References: https://cwe.mitre.org/data/definitions/798.html · https://cheatsheetseries.owasp.org/cheatsheets/Secrets_Management_Cheat_Sheet.html

<details><summary>1 advisory finding(s) — not blocking</summary>

| Severity | Tool | Location | Rule | Why not blocking |
|---|---|---|---|---|
| MEDIUM | semgrep | `app/java/src/main/java/edu/demo/CWE321_Hard_Coded_Cryptographic_Key__basic_01_bad.java:45` | `use-of-default-aes` | OWASP risk MEDIUM (likelihood MEDIUM x impact MEDIUM) below HIGH |

</details>

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 2 | 4.40 | 188 |
| gitleaks | ok | 0 | 0.51 | 61 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
