# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (3 findings) · 0 advisory · scope: 1 changed file(s) (`..c2f2c9f8e0`) · 9.9s · policy `adaptive-no_differential` v1

## Blocking issues — fix before merge

### 1. [CRITICAL] SQL Injection — CWE-89 — `app/java/src/main/java/edu/demo/CWE89_SQL_Injection__getCookies_Servlet_executeUpdate_01_bad.java:55`

- **Rule:** `dt074.java.sqli.tainted-jdbc` (semgrep, taint, confidence HIGH)
- **Why it blocks:** OWASP risk CRITICAL with confirmed source-to-sink data flow, confidence HIGH
- **Risk:** Attacker-controlled text is concatenated into an SQL statement, so it can change the query's meaning (read/modify/delete any row).
- **Also reported by:** `formatted-sql-string` (L55), `tainted-sql-from-http-request` (L47) — merged into one issue
- **Detail:** Untrusted input from 'request' reaches a JDBC query string. Use a PreparedStatement with '?' placeholders and bind the value with setString().

```java
  53 | 
  54 |             /* POTENTIAL FLAW: data concatenated into SQL statement used in executeUpdate(), which could result in SQL Injection */
> 55 |             int rowCount = sqlStatement.executeUpdate("insert into users (status) values ('updated') where name='"+data+"'");
  56 | 
  57 |             IO.writeLine("Updated " + rowCount + " rows successfully.");
```

**How to fix (java):**

```java
// Bind the value; never concatenate it into the SQL text.
try (PreparedStatement ps = conn.prepareStatement(
        "select * from users where name = ?")) {
    ps.setString(1, name);
    try (ResultSet rs = ps.executeQuery()) { /* ... */ }
}
```

References: https://cwe.mitre.org/data/definitions/89.html · https://cheatsheetseries.owasp.org/cheatsheets/Query_Parameterization_Cheat_Sheet.html

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 3 | 7.91 | 247 |
| gitleaks | ok | 0 | 0.50 | 62 |
| syft | ok | 0 | 1.26 | 187 |
| trivy | ok | 0 | 0.08 | 103 |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
