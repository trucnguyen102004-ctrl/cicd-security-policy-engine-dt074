# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (4 findings) · 0 advisory · scope: 1 changed file(s) (`..2fe88d801d`) · 10.8s · policy `adaptive-no_differential` v1

## Blocking issues — fix before merge

### 1. [CRITICAL] Path Traversal — CWE-22 — `app/java/src/main/java/edu/demo/CWE23_Relative_Path_Traversal__getCookies_Servlet_02_bad.java:67`

- **Rule:** `dt074.java.path.tainted-file-access` (semgrep, taint, confidence HIGH)
- **Why it blocks:** OWASP risk CRITICAL with confirmed source-to-sink data flow, confidence HIGH
- **Risk:** A user-supplied value controls a file path, so '../' or an absolute path can read or overwrite files outside the intended directory.
- **Also reported by:** `httpservlet-path-traversal` (L67), `httpservlet-path-traversal` (L75), `tainted-file-access` (L75) — merged into one issue
- **Detail:** Untrusted input from 'request' controls a filesystem path. Canonicalise the path and verify it stays under the allowed base directory, or keep only the file name (FilenameUtils.getName).

```java
  65 |         {
  66 |             /* POTENTIAL FLAW: no validation of concatenated value */
> 67 |             File file = new File(root + data);
  68 |             FileInputStream streamFileInputSink = null;
  69 |             InputStreamReader readerInputStreamSink = null;
```

**How to fix (java):**

```java
Path base = Paths.get("/srv/uploads").toRealPath();
Path target = base.resolve(userName).normalize();
if (!target.startsWith(base)) {
    throw new SecurityException("path escapes upload directory");
}
```

References: https://cwe.mitre.org/data/definitions/22.html · https://owasp.org/www-community/attacks/Path_Traversal

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 4 | 8.72 | 257 |
| gitleaks | ok | 0 | 0.49 | 62 |
| syft | ok | 0 | 1.40 | 178 |
| trivy | ok | 0 | 0.07 | 102 |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
