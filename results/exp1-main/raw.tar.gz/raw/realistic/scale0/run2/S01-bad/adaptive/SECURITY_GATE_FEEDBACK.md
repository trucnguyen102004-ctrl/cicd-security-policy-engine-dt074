# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (1 findings) · 0 advisory · scope: 2 changed file(s) (`ff7460e763..86f51451d8`) · 9.4s · policy `adaptive` v1

## Blocking issues — fix before merge

### 1. [CRITICAL] Security finding — default — `app/modules/S01_pyyaml_5.3.1_fullloader/requirements.txt`

- **Rule:** `CVE-2020-14343` (trivy, cve, confidence HIGH)
- **Why it blocks:** CRITICAL CVE introduced by this change
- **Risk:** The rule reported a potential weakness; review the linked CWE for context.
- **Detail:** pyyaml 5.3.1 is affected by CVE-2020-14343 (CRITICAL); fixed in 5.4

**How to fix (general):**

```text
Upgrade pyyaml 5.3.1 → 5.4
Follow the rule message and the CWE reference below.
```

References: https://avd.aquasec.com/nvd/cve-2020-14343

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 0 | 6.58 | 256 |
| gitleaks | ok | 0 | 0.48 | 61 |
| syft | ok | 0 | 2.14 | 177 |
| trivy | ok | 1 | 0.09 | 103 |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
