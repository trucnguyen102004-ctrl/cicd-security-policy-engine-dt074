# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (2 findings) · 0 advisory · scope: 1 changed file(s) (`eecd05ecf7..8c4c46d8f7`) · 5.2s · policy `adaptive` v1

## Blocking issues — fix before merge

### 1. [CRITICAL] Path Traversal — CWE-22 — `app/java/src/main/java/edu/demo/CWE23_Relative_Path_Traversal__Environment_01_bad.java:51`

- **Rule:** `dt074.java.path.tainted-file-access-nonweb` (semgrep, taint, confidence HIGH)
- **Why it blocks:** OWASP risk CRITICAL with confirmed source-to-sink data flow, confidence HIGH
- **Risk:** A user-supplied value controls a file path, so '../' or an absolute path can read or overwrite files outside the intended directory.
- **Also reported by:** `tainted-file-access-nonweb` (L59) — merged into one issue
- **Detail:** Data read from '"ADD"' (environment or I/O stream) controls a filesystem path. Canonicalise and confine it to the allowed base directory.

```java
  49 |         {
  50 |             /* POTENTIAL FLAW: no validation of concatenated value */
> 51 |             File file = new File(root + data);
  52 |             FileInputStream streamFileInputSink = null;
  53 |             InputStreamReader readerInputStreamSink = null;
```

**How to fix (java):**

```java
Path base = Paths.get("/srv/uploads").toRealPath();
Path target = base.resolve(userName).normalize();
if (!target.startsWith(base)) {
    throw new SecurityException("path escapes upload directory");
}
```

References: https://cwe.mitre.org/data/definitions/22.html · https://owasp.org/www-community/attacks/Path_Traversal

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 2 | 4.61 | 188 |
| gitleaks | ok | 0 | 0.49 | 57 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
