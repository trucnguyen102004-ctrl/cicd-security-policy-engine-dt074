# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (7 findings) · 0 advisory · scope: 2 changed file(s) (`84a9e3ac00..ffb2de64a6`) · 6.8s · policy `adaptive-no_sca_triage` v1

## Blocking issues — fix before merge

### 1. [CRITICAL] Security finding — default — `app/modules/S02_log4j_core_2.14.1/pom.xml`

- **Rule:** `CVE-2021-44228` (trivy, cve, confidence HIGH)
- **Why it blocks:** CRITICAL CVE introduced by this change
- **Risk:** The rule reported a potential weakness; review the linked CWE for context.
- **Also reported by:** `CVE-2021-44832` (L1), `CVE-2021-45046` (L1), `CVE-2021-45105` (L1), `CVE-2025-68161` (L1), `CVE-2026-34477` (L1), `CVE-2026-34480` (L1) — merged into one issue
- **Detail:** org.apache.logging.log4j:log4j-core 2.14.1 is affected by CVE-2021-44228 (CRITICAL); fixed in 2.15.0, 2.3.1, 2.12.2

**How to fix (general):**

```text
Upgrade org.apache.logging.log4j:log4j-core 2.14.1 → 2.15.0
Follow the rule message and the CWE reference below.
```

References: https://avd.aquasec.com/nvd/cve-2021-44228

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 0 | 4.61 | 194 |
| gitleaks | ok | 0 | 0.57 | 62 |
| syft | ok | 0 | 1.44 | 178 |
| trivy | ok | 7 | 0.10 | 105 |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
