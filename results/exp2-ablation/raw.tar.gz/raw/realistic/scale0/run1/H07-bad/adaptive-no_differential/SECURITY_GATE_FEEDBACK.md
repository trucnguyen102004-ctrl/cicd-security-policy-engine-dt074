# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (2 findings) · 6 advisory · scope: 5 changed file(s) (`..12acef8553`) · 12.1s · policy `adaptive-no_differential` v1

## Blocking issues — fix before merge

### 1. [HIGH] Cross-site Scripting (XSS) — CWE-79 — `app/java/src/main/java/edu/demo/CWE80_XSS__Servlet_getParameter_Servlet_03_bad.java:43`

- **Rule:** `dt074.java.xss.tainted-servlet-writer` (semgrep, taint, confidence HIGH)
- **Why it blocks:** OWASP risk HIGH with confirmed source-to-sink data flow, confidence HIGH
- **Risk:** Request data is written into an HTML response without output encoding, so a crafted value runs JavaScript in the victim's browser.
- **Also reported by:** `no-direct-response-writer` (L43) — merged into one issue
- **Detail:** Untrusted input from '"name"' is written to the HTTP response without HTML encoding. Encode it (OWASP Encoder Encode.forHtml / StringEscapeUtils.escapeHtml4).

```java
  41 |         {
  42 |             /* POTENTIAL FLAW: Display of data in web page without any encoding or validation */
> 43 |             response.getWriter().println("<br>bad(): data = " + data);
  44 |         }
  45 | 
```

**How to fix (java):**

```java
// OWASP Java Encoder: encode for the exact output context
import org.owasp.encoder.Encode;
response.getWriter().println("<br>data = " + Encode.forHtml(data));
```

References: https://cwe.mitre.org/data/definitions/79.html · https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html

<details><summary>6 advisory finding(s) — not blocking</summary>

| Severity | Tool | Location | Rule | Why not blocking |
|---|---|---|---|---|
| HIGH | semgrep | `app/python/service.py:28` | `directly-returned-format-string` | value passes through a known sanitiser on the reported line |
| HIGH | semgrep | `app/python/service.py:28` | `raw-html-format` | value passes through a known sanitiser on the reported line |
| MEDIUM | semgrep | `app/python/service.py:28` | `raw-html-format` | OWASP risk MEDIUM (likelihood MEDIUM x impact MEDIUM) below HIGH |
| HIGH | trivy | `app/java/pom.xml:1` | `CVE-2026-42198` | package is not imported by in-scope code |
| HIGH | trivy | `app/java/pom.xml:1` | `CVE-2026-54291` | package is not imported by in-scope code |
| LOW | trivy | `app/python/requirements.txt:1` | `CVE-2026-27205` | CVE severity LOW below HIGH |

</details>

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 5 | 9.73 | 280 |
| gitleaks | ok | 0 | 0.54 | 66 |
| syft | ok | 0 | 1.58 | 187 |
| trivy | ok | 3 | 0.09 | 105 |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
