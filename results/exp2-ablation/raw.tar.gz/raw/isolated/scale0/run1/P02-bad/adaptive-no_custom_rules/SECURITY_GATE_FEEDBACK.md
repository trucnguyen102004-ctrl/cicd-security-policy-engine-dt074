# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (1 findings) · 1 advisory · scope: 1 changed file(s) (`a4cedbedc7..16e66c0bff`) · 7.0s · policy `adaptive-no_custom_rules` v1

## Blocking issues — fix before merge

### 1. [HIGH] Cross-site Scripting (XSS) — CWE-79 — `app/python/CWE79_XSS__flask_args_response_01_bad.py:16`

- **Rule:** `python.django.security.injection.raw-html-format.raw-html-format` (semgrep, taint, confidence MEDIUM)
- **Why it blocks:** OWASP risk HIGH with confirmed source-to-sink data flow, confidence MEDIUM
- **Risk:** Request data is written into an HTML response without output encoding, so a crafted value runs JavaScript in the victim's browser.
- **Detail:** Detected user input flowing into a manually constructed HTML string. You may be accidentally bypassing secure methods of rendering HTML by manually constructing HTML and this could create a cross-site scripting vulnerability, which could let attackers steal sensitive user data. To be sure this is safe, check that the HTML is rendered safely. Otherwise, use templates (`django.shortcuts.render`) which will safely render HTML instead.

```python
  14 |     data = request.args.get("name")
  15 |     # POTENTIAL FLAW: display of data in web page without any encoding
> 16 |     return make_response("<br>bad(): data = " + data)
```

**How to fix (python):**

```python
from markupsafe import escape
return make_response("<br>data = " + escape(data))
# or render_template(...) with Jinja2 autoescaping (default in Flask)
```

References: https://cwe.mitre.org/data/definitions/79.html · https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html · https://docs.djangoproject.com/en/3.2/topics/http/shortcuts/#render

<details><summary>1 advisory finding(s) — not blocking</summary>

| Severity | Tool | Location | Rule | Why not blocking |
|---|---|---|---|---|
| MEDIUM | semgrep | `app/python/CWE79_XSS__flask_args_response_01_bad.py:16` | `raw-html-format` | OWASP risk MEDIUM (likelihood MEDIUM x impact MEDIUM) below HIGH |

</details>

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 2 | 6.45 | 251 |
| gitleaks | ok | 0 | 0.51 | 61 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
