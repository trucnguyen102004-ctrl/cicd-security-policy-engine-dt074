# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (2 findings) · 0 advisory · scope: 1 changed file(s) (`9b7c1f38c4..46f18b48a4`) · 5.2s · policy `adaptive-no_custom_rules` v1

## Blocking issues — fix before merge

### 1. [HIGH] Path Traversal — CWE-22 — `app/java/src/main/java/edu/demo/CWE36_Absolute_Path_Traversal__getParameter_Servlet_02_bad.java:47`

- **Rule:** `java.lang.security.httpservlet-path-traversal.httpservlet-path-traversal` (semgrep, taint, confidence MEDIUM)
- **Why it blocks:** OWASP risk HIGH with confirmed source-to-sink data flow, confidence MEDIUM
- **Risk:** A user-supplied value controls a file path, so '../' or an absolute path can read or overwrite files outside the intended directory.
- **Also reported by:** `httpservlet-path-traversal` (L55) — merged into one issue
- **Detail:** Detected a potential path traversal. A malicious actor could control the location of this file, to include going backwards in the directory with '../'. To address this, ensure that user-controlled variables in file paths are sanitized. You may also consider using a utility method such as org.apache.commons.io.FilenameUtils.getName(...) to only retrieve the file name from the path.

```java
  45 |         if (data != null)
  46 |         {
> 47 |             File file = new File(data);
  48 |             FileInputStream streamFileInputSink = null;
  49 |             InputStreamReader readerInputStreamSink = null;
```

**How to fix (java):**

```java
Path base = Paths.get("/srv/uploads").toRealPath();
Path target = base.resolve(userName).normalize();
if (!target.startsWith(base)) {
    throw new SecurityException("path escapes upload directory");
}
```

References: https://cwe.mitre.org/data/definitions/22.html · https://owasp.org/www-community/attacks/Path_Traversal · https://www.owasp.org/index.php/Path_Traversal

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 2 | 4.46 | 188 |
| gitleaks | ok | 0 | 0.65 | 61 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
