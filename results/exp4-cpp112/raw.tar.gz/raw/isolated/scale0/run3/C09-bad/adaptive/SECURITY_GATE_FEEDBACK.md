# 🔒 Security Gate: ✅ PASSED

**0 blocking issue(s)** (0 findings) · 1 advisory · scope: 1 changed file(s) (`1ab3db4e6a..aa4b9495aa`) · 4.1s · policy `adaptive` v1

<details><summary>1 advisory finding(s) — not blocking</summary>

| Severity | Tool | Location | Rule | Why not blocking |
|---|---|---|---|---|
| MEDIUM | semgrep | `app/c/src/CWE259_Hard_Coded_Password__w32_char_01_bad.c:33` | `insecure-use-string-copy-fn` | audit-grade rule (not a confirmed vulnerability) |

</details>

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 1 | 3.52 | 181 |
| gitleaks | ok | 0 | 0.51 | 58 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |
