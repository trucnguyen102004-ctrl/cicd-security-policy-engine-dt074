# 🔒 Security Gate: ❌ BLOCKED

**1 blocking issue(s)** (3 findings) · 0 advisory · scope: 1 changed file(s) (`65770087c6..0844083122`) · 6.7s · policy `adaptive-no_risk_threshold` v1

## Blocking issues — fix before merge

### 1. [CRITICAL] SQL Injection — CWE-89 — `app/java/src/main/java/edu/demo/CWE89_SQL_Injection__getParameter_Servlet_executeQuery_01_bad.java:47`

- **Rule:** `dt074.java.sqli.tainted-jdbc` (semgrep, taint, confidence HIGH)
- **Why it blocks:** OWASP risk CRITICAL with confirmed source-to-sink data flow, confidence HIGH
- **Risk:** Attacker-controlled text is concatenated into an SQL statement, so it can change the query's meaning (read/modify/delete any row).
- **Also reported by:** `formatted-sql-string` (L47), `tainted-sql-from-http-request` (L38) — merged into one issue
- **Detail:** Untrusted input from '"name"' reaches a JDBC query string. Use a PreparedStatement with '?' placeholders and bind the value with setString().

```java
  45 | 
  46 |             /* POTENTIAL FLAW: data concatenated into SQL statement used in executeQuery(), which could result in SQL Injection */
> 47 |             resultSet = sqlStatement.executeQuery("select * from users where name='"+data+"'");
  48 | 
  49 |             IO.writeLine(resultSet.getRow()); /* Use ResultSet in some way */
```

**How to fix (java):**

```java
// Bind the value; never concatenate it into the SQL text.
try (PreparedStatement ps = conn.prepareStatement(
        "select * from users where name = ?")) {
    ps.setString(1, name);
    try (ResultSet rs = ps.executeQuery()) { /* ... */ }
}
```

References: https://cwe.mitre.org/data/definitions/89.html · https://cheatsheetseries.owasp.org/cheatsheets/Query_Parameterization_Cheat_Sheet.html

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 3 | 6.08 | 189 |
| gitleaks | ok | 0 | 0.55 | 60 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |

<sub>Production emergency? A maintainer can add the `security-override` label and a line `Override-Reason: <ticket + justification>` to the PR description. Overrides are audited.</sub>
