# 🔒 Security Gate: ✅ PASSED

**0 blocking issue(s)** (0 findings) · 2 advisory · scope: 1 changed file(s) (`f91b55cd47..523a51feb7`) · 7.0s · policy `adaptive` v1

<details><summary>2 advisory finding(s) — not blocking</summary>

| Severity | Tool | Location | Rule | Why not blocking |
|---|---|---|---|---|
| HIGH | semgrep | `app/python/CWE79_XSS__flask_args_response_01_good.py:23` | `raw-html-format` | value passes through a known sanitiser on the reported line |
| MEDIUM | semgrep | `app/python/CWE79_XSS__flask_args_response_01_good.py:23` | `raw-html-format` | OWASP risk MEDIUM (likelihood MEDIUM x impact MEDIUM) below HIGH |

</details>

## Scanner summary

| Tool | Status | Findings | Wall time (s) | Max RSS (MB) |
|---|---|---|---|---|
| semgrep | ok | 2 | 6.40 | 250 |
| gitleaks | ok | 0 | 0.48 | 61 |
| syft | skipped | - | 0.00 | - |
| trivy | skipped | - | 0.00 | - |
